const { savetube } = require('../../toolkit/scrape/yt.js'); // Pastikan path ini benar
module.exports = {
  name: 'youtube',
  command: ['youtube', 'yt'],
  tags: 'Download Menu',
  desc: 'Download video dari YouTube.',
  prefix: true,
  Premium: true,
  run: async (conn, msg, {
    chatInfo,
    textMessage,
    prefix,
    commandText,
    args
  }) => {
    const { chatId, senderId, isGroup } = chatInfo;
    if (!(await isPrem(module.exports, conn, msg))) return;

    if (!args[0]) {
      return conn.sendMessage(chatId, { text: `Example:\n${prefix}${commandText} Url Youtube` }, { quoted: msg });
    }

    if (!args[0].includes('youtube.com') && !args[0].includes('youtu.be')) {
      return conn.sendMessage(chatId, { text: `Link yang kamu kirim tidak valid.` }, { quoted: msg });
    }

    await conn.sendMessage(chatId, { react: { text: '🕒', key: msg.key } });

    try {
      const hasil = await savetube.download(args[0], '720'); // Gunakan format 720p, bisa disesuaikan
      if (!hasil || !hasil.status) {
        return conn.sendMessage(chatId, { text: `Gagal mengunduh video: ${hasil?.error || 'Terjadi kesalahan.'}` }, { quoted: msg });
      }

      let text = `YouTube Downloader\n`;
      text += `\n\n`;
      text += `❏ *Title* : ${hasil.result.title}\n`;
      text += `❏ *Durasi* : ${hasil.result.duration}\n`;
      text += `❏ *Kualitas* : ${hasil.result.quality}\n`;
      text += `❏ *Download* : ${hasil.result.download}\n`;

      await conn.sendMessage(chatId, {
        video: { url: hasil.result.download },
        caption: text
      }, { quoted: msg, ephemeralExpiration: msg.expiration });

    } catch (err) {
      console.error(err);
      conn.sendMessage(chatId, { text: 'Maaf, terjadi kesalahan saat memproses video.' }, { quoted: msg });
    }
  }
};
